function [perimeters, areas] = calAP(a,b)
    perimeters = zeros(1,length(b));
    areas = zeros(1,length(b));
    for  i=1: length(b)
        if strcmp(a ,'circle')
            perimeters(i) = (2*pi*b(i));
            areas(i) = (pi*b(i)*b(i));
        elseif strcmp(a,'triangle')
            areas(i) = (sqrt(3)*b(i)*b(i)/4);
            perimeters(i) = (3*b(i));
        elseif strcmp(a, 'pentagon')
            areas(i) = (b(i)*b(i)*5/4*tan(0.942478));
            perimeters(i) = (5*b(i));
        elseif strcmp(a, 'hexagon')
            areas(i) =(b(i)*b(i)*3/2*sqrt(3));
            perimeters(i) =  (6*b(i));
        end
    end
end