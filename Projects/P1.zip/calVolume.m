function volumes = calVolume(a,b)
volumes = zeros(1,length(b));
for  i=1: length(b)
    if strcmp(a, 'sphere')
        volumes(i) = (4/3*pi*b(i)*b(i)*b(i));
    elseif strcmp(a, 'cylinder')
        Qdbl = cat(1,b{:});
        volumes(i) = (pi*Qdbl(i,1)*Qdbl(i,1)*Qdbl(i,2));
    elseif strcmp(a, 'right cone')
        Qdbl = cat(1,b{:});
        volumes(i) = (pi*Qdbl(i,1)*Qdbl(i,1)*Qdbl(i,2)/3);
    elseif strcmp(a, 'cube')
        volumes(i) =  (b(i)*b(i)*b(i));
    end
end
end

